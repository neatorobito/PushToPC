<?php
/*
Template Name: Typography Template
*/
get_header(); ?>

<div id="main">
    <?php if(function_exists('get_home_content')) echo get_home_content(); ?>
    <div class="section-content">
        <div class="content">
            <div class="holder">
                <?php if(have_posts()): ?>
                    <?php while(have_posts()): the_post(); ?>
                        <div class="frame">
                            <?php $postid = get_the_ID(); ?>
                            <?php $info = get_post_meta($postid, 'information', true); ?>
                            <?php $success = get_post_meta($postid, 'success', true); ?>
                            <?php $error = get_post_meta($postid, 'error', true); ?>
                            <?php if(!empty($info) || !empty($success) || !empty($error)): ?>
                                <div class="message-holder">
                                    <?php if(!empty($info)): ?>
                                        <div class="info-message">
                                            <div class="info-message-holder">
                                                <div class="info-message-frame">
                                                    <p><?php echo $info; ?></p>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                    <?php if(!empty($success)): ?>
                                        <div class="success-message">
                                            <div class="success-message-holder">
                                                <div class="success-message-frame">
                                                    <p><?php echo $success; ?></p>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                    <?php if(!empty($error)): ?>
                                        <div class="error-message">
                                            <div class="error-message-holder">
                                                <div class="error-message-frame">
                                                    <p><?php echo $error; ?></p>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>
                            <h1><span><?php the_title(); ?></span></h1>
                            <?php the_content(); ?>
                        </div>
                    <?php endwhile; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php get_footer(); ?>

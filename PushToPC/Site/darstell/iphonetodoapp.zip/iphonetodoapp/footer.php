		<div id="footer">
            <?php if(is_active_sidebar('footer-text')): ?>
                <?php dynamic_sidebar('footer-text'); ?>
            <?php endif; ?>			
            <?php wp_nav_menu(array('container' => false, 'theme_location' => 'secondary', 'menu_class' => 'footer-nav' )); ?>
            <?php if(is_active_sidebar('footer-copyright')): ?>
                <?php dynamic_sidebar('footer-copyright'); ?>
            <?php endif; ?>
        </div>
    </div>
		<?php wp_footer(); ?>
	</body>
</html>
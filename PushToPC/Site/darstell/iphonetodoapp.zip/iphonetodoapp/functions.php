<?php

include( TEMPLATEPATH.'/widgets.php' );

/**
 * Disable automatic general feed link outputting.
 */
automatic_feed_links( false );

//remove_action('wp_head', 'feed_links_extra', 3);
remove_action('wp_head', 'wp_generator');

if ( function_exists('register_sidebar') ) {
    register_sidebar(array(
        'id' => 'subscribe-sidebar',
        'name' => 'Subscribe Form',
        'before_widget' => '<div class="widget %2$s" id="%1$s">',
        'after_widget' => '</div>',
        'before_title' => '<h3>',
        'after_title' => '</h3>'
    ));
    
	register_sidebar(array(
		'id' => 'footer-copyright',
		'name' => 'Footer Copyright',
		'before_widget' => '<div class="widget %2$s" id="%1$s">',
		'after_widget' => '</div>',
		'before_title' => '<h3>',
		'after_title' => '</h3>'
	));
}

if ( function_exists( 'add_theme_support' ) ) {
	add_theme_support( 'post-thumbnails' );
	set_post_thumbnail_size( 50, 50, true ); // Normal post thumbnails
	add_image_size( 'single-post-thumbnail', 400, 9999, true );
    add_image_size( 'home-attach-thumbnail', 255, 382, true );
    add_image_size( 'feature-attach-thumbnail', 296, 472, true );
}

register_nav_menus( array(
	'primary' => __( 'Primary Navigation', 'base' ),
    'secondary' => __( 'Footer Navigation', 'base' ),
) );


//add [email]...[/email] shortcode
function shortcode_email($atts, $content) {
	$result = '';
	for ($i=0; $i<strlen($content); $i++) {
		$result .= '&#'.ord($content{$i}).';';
	}
	return $result;
}
add_shortcode('email', 'shortcode_email');

// register tag [template-url]
function filter_template_url($text) {
	return str_replace('[template-url]',get_bloginfo('template_url'), $text);
}
add_filter('the_content', 'filter_template_url');
add_filter('get_the_content', 'filter_template_url');
add_filter('widget_text', 'filter_template_url');

// register tag [site-url]
function filter_site_url($text) {
	return str_replace('[site-url]',get_bloginfo('url'), $text);
}
add_filter('the_content', 'filter_site_url');
add_filter('get_the_content', 'filter_site_url');
add_filter('widget_text', 'filter_site_url');


/* Replace Standart WP Menu Classes */
function change_menu_classes($css_classes) {
        $css_classes = str_replace("current-menu-item", "active", $css_classes);
        $css_classes = str_replace("current-menu-parent", "active", $css_classes);
        return $css_classes;
}
add_filter('nav_menu_css_class', 'change_menu_classes');


//allow tags in category description
$filters = array('pre_term_description', 'pre_link_description', 'pre_link_notes', 'pre_user_description');
foreach ( $filters as $filter ) {
    remove_filter($filter, 'wp_filter_kses');
}


//Make WP Admin Menu HTML Valid
function wp_admin_bar_valid_search_menu( $wp_admin_bar ) {
	if ( is_admin() )
		return;

	$form  = '<form action="' . esc_url( home_url( '/' ) ) . '" method="get" id="adminbarsearch"><div>';
	$form .= '<input class="adminbar-input" name="s" id="adminbar-search" tabindex="10" type="text" value="" maxlength="150" />';
	$form .= '<input type="submit" class="adminbar-button" value="' . __('Search') . '"/>';
	$form .= '</div></form>';

	$wp_admin_bar->add_menu( array(
		'parent' => 'top-secondary',
		'id'     => 'search',
		'title'  => $form,
		'meta'   => array(
			'class'    => 'admin-bar-search',
			'tabindex' => -1,
		)
	) );
}
function fix_admin_menu_search() {
	remove_action( 'admin_bar_menu', 'wp_admin_bar_search_menu', 4 );
	add_action( 'admin_bar_menu', 'wp_admin_bar_valid_search_menu', 4 );
}
add_action( 'add_admin_bar_menus', 'fix_admin_menu_search' );


function get_home_content(){
    $page_data = get_page(get_option('page_on_front'));
    if($page_data){
    $output .= '<div class="visual">';
             $attachments = get_children(array('post_parent' => $page_data->ID,
                      'post_type' => 'attachment',
                      'post_mime_type' => 'image',
                      'orderby' => 'menu_order',
                      'order' => 'ASC',
                      'exclude' => get_post_thumbnail_id()));
                              
                if($attachments)
                {
                    $output .= '<div class="gallery">';
                    $output .= '<div class="gallery-holder">';
                    $output .= '<div class="gallery-frame">';
                    $output .= '<ul class="gallery-list">';
                        foreach($attachments as $att_id => $attachment) 
                        {
                            $output .= '<li class="active">'.wp_get_attachment_image($attachment->ID, 'home-attach-thumbnail').'</li>';
                        } 
                    $output .= '</ul></div></div>';
                    $output .= '<div class="switcher-holder"></div></div>';
               } 
    $output .= '<div class="section-promo">';
    $output .=  apply_filters('the_content', $page_data->post_content);   
    $output .= '</div>';
    
    $price = get_post_meta($page_data->ID, 'price', true);
    
    if($price){
        $output .= '<div class="price-cont">';
        $output .= '<div class="prise"><div class="prise-holder"><span>';
        $output .= $price;
        $output .= '</span></div></div></div>';
    }
    
    $output .= '</div>';
    
    return $output;
    }else{
        return;
    }
}

// Features Custom Pots Type
add_action('init','theme_custom_init');
function theme_custom_init(){
 $labels = array(
  'name' => _x('Features', 'post type general name'),
  'singular_name' => _x('Feature', 'post type singular name'),
  'add_new' => _x('Add Feature', 'House'),
  'add_new_item' => __('Add New Feature'),
  'edit_item' => __('Edit Feature'),
  'new_item' => __('New Feature'),
  'all_items' => __('All Features'),
  'view_item' => __('View Features'),
  'search_items' => __('Search Features'),
  'not_found' =>  __('No Features found'),
  'not_found_in_trash' => __('No Features found in Trash'), 
  'parent_item_colon' => '',
  'menu_name' => 'Features'
 );
 $args = array(
  'labels' => $labels,
  'public' => true,
  'publicly_queryable' => true,
  'show_ui' => true, 
  'show_in_menu' => true, 
  'query_var' => true,
  'rewrite' => true,
  'capability_type' => 'post',
  'has_archive' => true, 
  'hierarchical' => false,
  'menu_position' => null,
  'supports' => array('title','editor','author','thumbnail','excerpt','comments','custom-fields')
 ); 
 register_post_type('features',$args);
} ?>
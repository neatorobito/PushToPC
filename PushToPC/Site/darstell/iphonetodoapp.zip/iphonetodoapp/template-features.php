<?php
/*
Template Name: Features Template
*/
get_header(); ?>

<div id="main">
    <?php if(function_exists('get_home_content')) echo get_home_content(); ?>
    <?php query_posts('post_type=features'); ?>
        <?php if(have_posts()): ?>
            <div class="section-content">
                <div class="content">
                    <div class="holder">
                        <div class="frame">
                            <div class="post-holder">
                                <?php while(have_posts()): the_post(); ?>
                                    <div class="post">
                                        <div class="post-frame">
                                            <?php if(has_post_thumbnail()):
                                                 $image_id = get_post_meta(get_the_ID(), '_thumbnail_id',true);
                                                 $attachment = get_post($image_id);
                                                 $image_class = $attachment->post_excerpt; ?>
                                                <?php $attr= array('class' => $image_class); ?>
                                                <?php the_post_thumbnail('feature-attach-thumbnail', $attr); ?>
                                            <?php endif; ?>
                                            <div class="text-holder">
                                                <h2><a href="<?php the_permalink(); ?>"><span><?php the_title(); ?></span></a></h2>
                                                <?php the_content(); ?>
                                            </div>
                                        </div>
                                    </div>
                                <?php endwhile; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    <?php wp_reset_query(); ?>
</div>

<?php get_footer(); ?>

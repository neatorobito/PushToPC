<?php
/*
Template Name: Home Template
*/
get_header(); ?>

<div id="main">
    <?php if(function_exists('get_home_content')) echo get_home_content(); ?>
    <?php if(is_active_sidebar('subscribe-sidebar')): ?>
        <div class="container">
            <?php dynamic_sidebar('subscribe-sidebar'); ?>
        </div>
    <?php endif; ?>
</div>

<?php get_footer(); ?>

<?php get_header(); ?>

<div id="main" class="blog">
    <div class="phone-holder"><img src="<?php bloginfo('template_url'); ?>/images/bg-gallery.png" width="334" height="599" alt="image description" /></div>
    <div class="section-content form-holder">
        <div class="content">
            <div class="holder">
                <div class="frame">
	                <?php if (have_posts()) : ?>
	                    <?php while (have_posts()) : the_post(); ?>
	                        <div class="post" id="post-<?php the_ID(); ?>">
		                        <div class="title">
			                        <h2><span><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title_attribute(); ?>"><?php the_title(); ?></a></span></h2>
			                        <p class="info"><strong class="date"><?php the_time('F jS, Y') ?></strong> by <?php the_author(); ?></p>
		                        </div>
			                    <?php the_content('Read the rest of this entry &raquo;'); ?>
		                        <div class="meta">
			                        <ul>
				                        <li>Posted in <?php the_category(', ') ?></li>
				                        <li><?php comments_popup_link('No Comments', '1 Comment', '% Comments'); ?></li>
				                        <?php the_tags('<li>Tags: ', ', ', '</li>'); ?>
			                        </ul>
		                        </div>
	                        </div>
	                    <?php endwhile; ?>
	                    <div class="navigation">
		                    <div class="next"><?php next_posts_link('Older Entries &raquo;') ?></div>
		                    <div class="prev"><?php previous_posts_link('&laquo; Newer Entries') ?></div>
	                    </div>
	                <?php else : ?>
	                    <div class="post">
                            <div class="title">
                                <h1><span>Not Found</span></h1>
                            </div>
                            <p>Sorry, but you are looking for something that isn't here.</p>
                        </div>
	                <?php endif; ?>
	            </div>
            </div>
        </div>
    </div>
</div>

<?php get_footer(); ?>
<?php get_header(); ?>

<div id="main">
    <div class="phone-holder"><img src="<?php bloginfo('template_url'); ?>/images/bg-gallery.png" width="334" height="599" alt="image description" /></div>
    <div class="section-content form-holder">
        <div class="content">
            <div class="holder">
                <div class="frame">
                    <h1><span>Not Found</span></h1>
                    <p>Sorry, but you are looking for something that isn't here.</p>
                </div>
            </div>
        </div>
    </div>
</div>

<?php get_footer(); ?>
